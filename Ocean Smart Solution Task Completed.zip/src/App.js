// import logo from './logo.svg';
import './App.css';
// import '../src/components/Form'
import Form from '../src/components/Form';

function App() {
  return (
    <div className="App">
      <Form/>
    </div>
  );
}

export default App;
