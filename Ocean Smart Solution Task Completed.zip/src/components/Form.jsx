import React, { useState } from 'react';
import { PDFDownloadLink, Document, Page, View,  Text, StyleSheet } from '@react-pdf/renderer';
import './Form.css'

const Form = () => {
  const [name, setName] = useState('');
  const [course, setCourse] = useState('B.tech');

  const handleNameChange = (e) => {
    setName(e.target.value);
  };

  const handleCourseChange = (e) => {
    setCourse(e.target.value);
  };

  const getOptionLabel = (value) => {
    return course === value ? `✓ ${value}` : value;
  };

  const BtechTemplate = () => (
    <Document>
      <Page style={styles.page}>
        {/* <Text style={styles.title}>Offer Letter for M.Tech</Text> */}
        <Text style={styles.name}>Ref - A101 </Text>
        <Text style={styles.name}>Name: {name}</Text>
        <Text style={styles.course}>Course: {course}</Text>
        <Text style={styles.date}>Date of Offer: {new Date().toLocaleDateString()}</Text>
        <Text style={styles.Fs}>Free Structure:</Text>
        <View style={styles.table}>
          <View style={styles.tableRow}>
            <Text style={styles.tableCell}>Year</Text>
            <Text style={styles.tableCell}>One-time Fee</Text>
            <Text style={styles.tableCell}>Tuition Fee</Text>
          </View>
          <View style={styles.tableRow}>
            <Text style={styles.tableCell}>1</Text>
            <Text style={styles.tableCell}>500</Text>
            <Text style={styles.tableCell}>160</Text>
          </View>
          <View style={styles.tableRow}>
            <Text style={styles.tableCell}>2</Text>
            <Text style={styles.tableCell}>-</Text>
            <Text style={styles.tableCell}>160</Text>
          </View>
        </View>
      </Page>
    </Document>
  );

  const MtechTemplate = () => (
    <Document>
      <Page style={styles.page}>
        {/* <Text style={styles.title}>Offer Letter for B.Tech</Text> */}
        <Text style={styles.name}>Ref - B101 </Text>
        <Text style={styles.name}>Name: {name}</Text>
        <Text style={styles.course}>Course: {course}</Text>
        <Text style={styles.date}>Date of Offer: {new Date().toLocaleDateString()}</Text>
        <Text style={styles.Fs}>Free Structure:</Text>
        <View style={styles.table}>
          <View style={styles.tableRow}>
            <Text style={styles.tableCell}>Year</Text>
            <Text style={styles.tableCell}>One-time Fee</Text>
            <Text style={styles.tableCell}>Tuition Fee</Text>
          </View>
          <View style={styles.tableRow}>
            <Text style={styles.tableCell}>1</Text>
            <Text style={styles.tableCell}>600</Text>
            <Text style={styles.tableCell}>260</Text>
          </View>
          <View style={styles.tableRow}>
            <Text style={styles.tableCell}>2</Text>
            <Text style={styles.tableCell}>-</Text>
            <Text style={styles.tableCell}>260</Text>
          </View>
        </View>
      </Page>
    </Document>
  );

  return (
    <div style={styles.form}>
      <label style={styles.label}>
        Name:
        <input style={styles.input} type="text" value={name} onChange={handleNameChange} />
      </label>
      <label style={styles.label}>
        Course:
        <select style={styles.input} value={course} onChange={handleCourseChange}>
          <option style={styles.Option} value="B.tech">{getOptionLabel("B.tech")}</option>
          <option style={styles.Option} value="M.tech">{getOptionLabel("M.tech")}</option>
        </select>
      </label>
      <div style={styles.Buttons}>

      <span style={styles.SubmitButton} className="SubmitButton" >Submit</span>
        <PDFDownloadLink style={{textDecoration:"none"}} document={course === 'B.tech' ? <BtechTemplate /> : <MtechTemplate />} fileName="OfferLetter.pdf">
          {({ blob, url, loading, error }) =>
            loading ? <input type='Submit' /> : <span style={styles.PDFButton} className="PDFButton">Generate PDF</span> 
          }
        </PDFDownloadLink>
      </div>
    </div>
  );
};

const styles = StyleSheet.create({
    page: {
        flexDirection: 'column',
        backgroundColor: '#ffffff',
        padding: 20,
      },
      title: {
        fontSize: 18,
        textAlign: 'center',
        marginBottom: 20,
      },
      date: {
        fontSize: 12,
        marginBottom: 10,
      },
      name: {
        fontSize: 12,
        marginBottom: 10,
      },
      course: {
        fontSize: 12,
        marginBottom: 10,
    },
    Fs : {
        fontSize: 12,
      },
      table: {
        marginTop: 20,
        // flexDirection: 'column',
        border: '1px solid #000',
      },
      tableRow: {
        flexDirection: 'row',
        justifyContent : 'space-between',
        width:'auto',
        borderBottom: '1px solid #000',
      },
      tableCell: {
        padding : '4',
        width:'100%',
        fontSize: 12,
        textAlign: 'left',
         borderRight: '1px solid #000',
      },
      form : {
        width: '100%',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: "center",
        gap: '10px',
        // paddingLeft:'5px'
        // margin: ''
      },
      input :{
        width : '95%',
        marginTop:'10px',
        marginLeft:'5px'
      },
      label : {
        fontWeight : "bold",
        display: 'flex',
        marginLeft:'10px',
        // justifyContent: "flex-start",
        // alignItems: "center",
        flexDirection: 'column'
      },
      PDFButton : {
        backgroundColor:'rgb(40,165,65)',
        color: 'white',
        textDecoration: 'none',
        padding: '10px 15px',
        borderRadius: '5px'
      },
      SubmitButton: {
        width:'75px',
        backgroundColor:'rgb(0,120,255)',
        color:'white',
        padding: '10px 15px',
        borderRadius:'5px',
        textAlign:"center"
      },
      Buttons:{
        display: 'flex',
        alignItems:'center',
        gap:'10px',
        marginLeft:'10px'
      },
      Option : {
        backgroundColor: 'rgb(70,95,80)',
        color:'white'
      }
});



export default Form;
